package com.kabigon.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.kabigon.domain.GroupEntity;
import com.kabigon.domain.UserEntity;

public interface GroupRepository extends JpaRepository<GroupEntity, Long> {
	GroupEntity findByOwner(UserEntity owner);
}
