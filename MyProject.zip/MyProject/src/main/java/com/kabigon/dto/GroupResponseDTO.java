package com.kabigon.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Getter
@Builder
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class GroupResponseDTO {
	private Long groupNo;
    private Long userNo;
    private String groupName;
    private Boolean isPublic;
    private String groupIntro;
    private String groupPicture;
    private Boolean isMaster;
}
