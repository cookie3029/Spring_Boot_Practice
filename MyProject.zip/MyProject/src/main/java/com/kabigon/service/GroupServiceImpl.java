package com.kabigon.service;

import com.kabigon.domain.UserEntity;
import com.kabigon.dto.GroupRequestDTO;
import com.kabigon.dto.GroupResponseDTO;
import com.kabigon.dto.UserRequestDTO;
import com.kabigon.repository.GroupRepository;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class GroupServiceImpl implements GroupService {
	private final UserService userService;
	private final GroupRepository groupRepository;
	
	@Override
	public GroupResponseDTO createGroup(GroupRequestDTO dto) {
		UserEntity user = userService.getUser(UserRequestDTO.builder().userNo(dto.getUserNo()).build());
		
		
		return null;
	}

	@Override
	public GroupResponseDTO updateGroupInfo(GroupRequestDTO dto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public GroupResponseDTO changeGroupMaster(GroupRequestDTO dto) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public GroupResponseDTO deleteGroup(GroupRequestDTO dto) {
		// TODO Auto-generated method stub
		return null;
	}

}
