package com.kabigon.service;

import com.kabigon.dto.GroupRequestDTO;
import com.kabigon.dto.GroupResponseDTO;

public interface GroupService {
	public GroupResponseDTO createGroup(GroupRequestDTO dto);
	public GroupResponseDTO updateGroupInfo(GroupRequestDTO dto);
	public GroupResponseDTO changeGroupMaster(GroupRequestDTO dto);
	public GroupResponseDTO deleteGroup(GroupRequestDTO dto);
	
}
