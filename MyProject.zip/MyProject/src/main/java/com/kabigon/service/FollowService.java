package com.kabigon.service;

import java.util.List;

import com.kabigon.domain.FollowEntity;
import com.kabigon.domain.TodoEntity;
import com.kabigon.domain.UserEntity;
import com.kabigon.dto.FollowResponseDTO;
import com.kabigon.dto.FollowStateResponseDTO;
import com.kabigon.dto.TodoRequestDTO;
import com.kabigon.dto.UserResponseDTO;

public interface FollowService {
	public FollowEntity getEntity(Long userNo, Long partnerNo);

	public FollowResponseDTO setFollow(Long userNo, Long partnerNo);
	public FollowResponseDTO setUnFollow(Long userNo, Long partnerNo);
	public FollowResponseDTO isfollowBack(Long userNo, Long partnerNo);
	
	public List<UserResponseDTO> followerList(Long userNo);
	public List<UserResponseDTO> followingList(Long userNo);
	public List<UserResponseDTO> followBackList(Long userNo); // 사용자 친구 리스트 (맞팔)
	public List<FollowStateResponseDTO> followState(String findName);
	
	public int checkPublicStateToTarget(Long userNO, Long partnerNo);
}
